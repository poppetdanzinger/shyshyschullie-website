Serifiqo 4F Free Capitals

� 2009 by Sergiy S. Tkachenko / 4th february (info@4thfebruary.com.ua).
All rights reserved. This font software is the property of Sergiy S. Tkachenko (Kremenchuk, Ukraine). You may not reproduce, modify, adapt, translate, alter nor create derivative works of the font software. You may not reverse engineer, decompile, decrypt, disassemble, nor seek to discover the source code of the font software.



If you used this font or saw where this font used please send me a photo, or link, or just few words where you saw. Thanks in advance!
